#include "highgui.h"


int main( int argc, char** argv ) {
	
	cvNamedWindow( "SimpIP", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;
	IplImage *Temp1;


	int controlPos=1;
	frame = cvQueryFrame( capture );
	Temp1= cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 3 );

	cvCreateTrackbar("alpha","SimpIP",&controlPos,100,NULL);
	cvSetTrackbarPos("dividir","SimpIP",1);
	
	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
	 cvCopy(frame,Temp1);
     cvFlip(Temp1,Temp1,1); 
	 //cvAddWeighted(frame,G_alpha,Temp1,(1-G_alpha),0,frame);
	 cvAddWeighted(frame,controlPos/100.0,Temp1,(1-controlPos/100.0),0,frame); 
	 // Try it also with cvSub, cvXor cvMul, cvDiv , cvAbsDiff..
	 cvShowImage( "SimpIP", frame );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "SimpIP" );
}