#include "highgui.h"
int G_Width;

void onChange(int pos){
	G_Width=pos;
}

int main( int argc, char** argv ) {
	cvNamedWindow( "CaptGui", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	IplImage* frame;
	int controlPos;

	frame = cvQueryFrame( capture );
	cvCreateTrackbar("divide","CaptGui",&controlPos,frame->width,onChange);
	G_Width=frame->width/2;
	cvSetTrackbarPos("divide","CaptGui",G_Width);
	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){
			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
	}
	G_Width=(G_Width>0)?G_Width:1;
	cvSetImageROI(frame, cvRect(0,0,G_Width,frame->height));
	cvNot(frame,frame);
	cvResetImageROI(frame);
	cvShowImage( "CaptGui", frame );
	char c = cvWaitKey(33);
	if( (c & 255) == 27 ) break;
}
cvReleaseCapture( &capture );
cvDestroyWindow( "CaptGui" );
}