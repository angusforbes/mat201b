#include "highgui.h"



int main( int argc, char** argv ) {

	IplImage *R;
	IplImage *G;
	IplImage *B;

	cvNamedWindow( "R", CV_WINDOW_AUTOSIZE );
	cvNamedWindow( "G", CV_WINDOW_AUTOSIZE );
	cvNamedWindow( "B", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	R = cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1 );
	G = cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1 );
	B = cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1 );

	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
	cvSplit(frame,B,G,R,NULL);

	cvShowImage( "R", R );// las ventanas deben existir
	cvShowImage( "G", G );
	cvShowImage( "B", B );
	char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
	}



	cvReleaseImage(&R);
	cvReleaseImage(&G);
	cvReleaseImage(&B);
	cvDestroyWindow( "R" );
	cvDestroyWindow( "G" );
	cvDestroyWindow( "B" );


}