#include "highgui.h"


int main( int argc, char** argv ) {
	IplImage *Temp1;
	IplImage *mask;

	cvNamedWindow( "Ex4Mask", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1 = cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 3 );
	mask = cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1 );
	cvSetZero(mask);
	cvSet(Temp1,cvScalarAll(255));
	cvCircle(mask,cvPoint(frame->width*2/3,frame->height/8),20,cvScalarAll(255),-1,8);
	cvCircle(mask,cvPoint(frame->width/3,frame->height/8),20,cvScalarAll(255),-1,8);
	cvCircle(mask,cvPoint(frame->width/2,frame->height/2),20,cvScalarAll(255),-1,8);
	cvEllipse(mask,cvPoint(frame->width/2,frame->height/2),
		cvSize(frame->width/3,frame->height/3),0,180,360,cvScalarAll(255),10,8,0);




	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
		cvCopy(frame,Temp1);
		cvNot(Temp1,Temp1);
		cvCopy(Temp1,frame,mask);
		cvShowImage( "Ex4Mask", frame );
		char c = cvWaitKey(10);
		if( (c & 255) == 27 ) break;
}

cvReleaseImage(&mask);
cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "Ex4Mask" );
}