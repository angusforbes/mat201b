#include "highgui.h"
#include "cv.h"


int main( int argc, char** argv ) {

	IplImage * TheColormap;
	IplImage * Temp1;
	IplImage * Temp2;

	
	cvNamedWindow( "Ex6PC", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );
	TheColormap= cvLoadImage("jeth.tif",-1);
	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp2=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 3);



	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
		cvCvtColor(frame,Temp1,CV_BGR2GRAY);
		cvCvtColor(Temp1,frame,CV_GRAY2BGR);
	    cvLUT( frame, Temp2,TheColormap);



		 cvShowImage( "Ex6PC", Temp2 );
	    char c = cvWaitKey(10);
	   if( (c & 255) == 27 ) break;
}
cvReleaseImage(&Temp1);
cvReleaseImage(&Temp2);
cvReleaseImage(&TheColormap);
cvReleaseCapture( &capture );
cvDestroyWindow( "Ex6PC" );
}