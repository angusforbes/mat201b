#include "highgui.h"
#include "cv.h"


#define Nx 640
#define Ny 480

CvMat  *MatMapX;
CvMat  *MatMapY;
float G_MapX[Nx*Ny];

float G_MapY[Nx*Ny];

int main( int argc, char** argv ) {
	

	IplImage * Temp1;
	float x,y,theta;


	cvNamedWindow( "Ex7_MAP", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	for (int k=0;k<Nx;k++){
		for (int q=0;q<Ny;q++){
			x=k-Nx/2.0;
			y=(q-Ny/2.0)/(Ny/2.0)*(3.14159)/2.0;
			G_MapX[q*Nx+k]=x/cos(y)+Nx/2.0;
			G_MapY[q*Nx+k]=q;
		}
	}

	MatMapX = cvCreateMat(Ny,Nx,CV_32FC1);
	MatMapY = cvCreateMat(Ny,Nx,CV_32FC1);

	cvInitMatHeader(MatMapX, Ny, Nx, CV_32FC1, G_MapX );
	cvInitMatHeader(MatMapY, Ny, Nx, CV_32FC1, G_MapY );

	IplImage* frame;
//
	frame = cvQueryFrame( capture );
	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 3);


	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

	cvRemap(frame,Temp1,MatMapX,MatMapY,
		CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS,CV_RGB(223,134,213));
	cvCopy(Temp1,frame);


		 cvShowImage( "Ex7_MAP", frame );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}


cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "Ex7_MAP" );
}