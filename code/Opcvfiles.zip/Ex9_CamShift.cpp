#include "highgui.h"
#include "cv.h"

int main( int argc, char** argv ) {
	
	IplImage * GRIS;
	IplImage * Temp1;
	IplImage * H;
	IplImage * Temp2;
	IplImage * Temp3;
	IplImage * masca;


	CvHistogram *G_hist1;
	int bins=64;
	float ranges_arr[] = {0,180};
	float* ranges = ranges_arr;
	G_hist1 = cvCreateHist( 1, &bins, CV_HIST_ARRAY, &ranges, 1 );
	CvRect G_window1;
	CvConnectedComp comp1;
	CvBox2D box1;





	cvNamedWindow( "Ex8BP", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 3);

	GRIS=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	H=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp2=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp3=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	masca=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);

// Training mode

	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

	cvCvtColor(frame,Temp1,CV_BGR2HSV);
	cvSplit(Temp1,H,Temp2,Temp3,NULL);
	cvInRangeS( Temp1, cvScalar(0,60,60,0),
                        cvScalar(180,256,220,0), masca );

	G_window1=cvRect(frame->width/2-20,frame->height/2-20,40,40);
	cvSetImageROI(H,cvRect(frame->width/2-20,frame->height/2-20,
								40,40));
	cvSetImageROI(masca,cvRect(frame->width/2-20,frame->height/2-20,
								40,40));
	cvSetImageROI(frame,cvRect(frame->width/2-20,frame->height/2-20,
								40,40));
	cvNot(frame,frame);
	cvCalcHist( &H,G_hist1, 0, masca );
	cvNormalizeHist(G_hist1,255);
	cvResetImageROI(H);
	cvResetImageROI(masca);
	cvResetImageROI(frame);
   cvShowImage( "Ex8BP", frame );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

// Execution mode

while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

		cvCvtColor(frame,Temp1,CV_BGR2HSV);
		cvSplit(Temp1,H,Temp2,Temp3,NULL);
		cvCalcBackProject( &H, Temp2, G_hist1 ); // calculating backprojection
	
		cvCamShift( Temp2, G_window1,
                        cvTermCriteria( CV_TERMCRIT_EPS | CV_TERMCRIT_ITER, 10, 1 ),
                        &comp1, &box1 );

		G_window1 = comp1.rect;
		box1.angle=(90 - box1.angle);
		cvEllipseBox(frame,box1,CV_RGB(255,0,0),3,CV_AA,0);
		cvShowImage("Ex8BP",frame);
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}




		cvReleaseImage(&H);
		cvReleaseImage(&Temp2);
		cvReleaseImage(&Temp3);
		cvReleaseImage(&GRIS);
		cvReleaseImage(&masca);
cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "Ex8BP" );
}