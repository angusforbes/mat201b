#include "highgui.h"
#include "cv.h"


void saltandpepper(IplImage* Ima1){
	IplImage *WhitePixels;
	IplImage *White;
	IplImage *Black;
	
	CvRNG rng = cvRNG(rand());
	White=cvCreateImage( cvGetSize(Ima1),IPL_DEPTH_8U, 3);
	Black=cvCreateImage( cvGetSize(Ima1),IPL_DEPTH_8U, 3);

	WhitePixels=cvCreateImage( cvGetSize(Ima1),IPL_DEPTH_8U, 1);
	cvSet(White,cvScalarAll(255));

	cvRandArr(&rng,WhitePixels,CV_RAND_UNI,cvScalarAll(0),cvScalarAll(255));
	cvThreshold(WhitePixels,WhitePixels,250,255,CV_THRESH_BINARY);
	cvCopy(White,Ima1,WhitePixels);
	cvSet(Black,cvScalarAll(0));

	cvRandArr(&rng,WhitePixels,CV_RAND_UNI,cvScalarAll(0),cvScalarAll(255));
	cvThreshold(WhitePixels,WhitePixels,250,255,CV_THRESH_BINARY);
	cvCopy(Black,Ima1,WhitePixels);


	cvReleaseImage(&Black);
	cvReleaseImage(&WhitePixels);
	cvReleaseImage(&White);
}


int main( int argc, char** argv ) {
	IplImage *Temp1;

	cvNamedWindow( "ExS2-1", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1 = cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 3 );


	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

			saltandpepper(frame);

			//cvSmooth(...);



		 cvShowImage( "ExS2-1", frame );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "ExS2-1" );
}