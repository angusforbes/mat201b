#include "highgui.h"
#include "cv.h"


int main( int argc, char** argv ) {
	
	IplImage * Temp1;
	
    CvMemStorage* storage = cvCreateMemStorage(0);
    CvSeq* lines = 0;



	cvNamedWindow( "ExS2-12", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);



	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
		cvCvtColor(frame,Temp1,CV_BGR2GRAY);
		cvCanny(Temp1,Temp1,50, 200, 3 );
		lines = cvHoughLines2( Temp1, storage, CV_HOUGH_STANDARD, 1, CV_PI/180, 100, 0, 0 );


		for(int  i = 0; i < MIN(lines->total,100); i++ )
		{
			float* line = (float*)cvGetSeqElem(lines,i);
			float rho = line[0];
			float theta = line[1];
			CvPoint pt1, pt2;
			double a = cos(theta), b = sin(theta);
			double x0 = a*rho, y0 = b*rho;
			pt1.x = cvRound(x0 + 1000*(-b));
			pt1.y = cvRound(y0 + 1000*(a));
			pt2.x = cvRound(x0 - 1000*(-b));
			pt2.y = cvRound(y0 - 1000*(a));
			cvLine( frame, pt1, pt2, CV_RGB(255,0,0), 3, CV_AA, 0 );
		}


		 cvShowImage( "ExS2-12", frame );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

cvReleaseMemStorage(&storage);
cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "ExS2-12" );
}