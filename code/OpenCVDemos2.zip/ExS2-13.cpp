#include "highgui.h"
#include "cv.h"


int main( int argc, char** argv ) {
	
	IplImage * Temp1;
	
    CvMemStorage* storage = cvCreateMemStorage(0);
    CvSeq* circles = 0;


	cvNamedWindow( "ExS2-13", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);


	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

		cvCvtColor(frame,Temp1,CV_BGR2GRAY);
		cvSmooth(Temp1, Temp1, CV_GAUSSIAN, 9, 9	);
		circles = cvHoughCircles( Temp1, storage, CV_HOUGH_GRADIENT,2,frame->width/20);
		for( int i = 0; i < MIN(circles->total,1); i++ ){
			float* p = (float*)cvGetSeqElem( circles, i );
			cvCircle( frame, cvPoint(cvRound(p[0]),cvRound(p[1])), cvRound(p[2]), CV_RGB(255,0,0), 3, 8, 0 );
		}



		 cvShowImage( "ExS2-13", frame );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}
	cvReleaseMemStorage(&storage);

cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "ExS2-13" );
}