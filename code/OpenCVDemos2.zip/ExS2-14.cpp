#include "highgui.h"
#include "cv.h"


	IplImage * G_Template;



int main( int argc, char** argv ) {
	
		IplImage * salida;
		IplImage * GRIS;
		double minval,maxval;
		CvPoint  Minpos;
		CvPoint  Maxpos;

		cvNamedWindow( "Frame", CV_WINDOW_AUTOSIZE );
		cvNamedWindow( "salida", CV_WINDOW_AUTOSIZE );
		cvNamedWindow( "Template", CV_WINDOW_AUTOSIZE );
		G_Template = cvLoadImage("A.png",0);
		cvShowImage("Template",G_Template);


		CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	GRIS = cvCreateImage(cvGetSize(frame),IPL_DEPTH_8U,1);
	salida = cvCreateImage(cvSize(frame->width-G_Template->width +1,
			frame->height-G_Template->height+1),32,1);


	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
		cvCvtColor(frame,GRIS,CV_BGR2GRAY);
		cvMatchTemplate(GRIS,G_Template,salida,CV_TM_CCOEFF_NORMED);
		cvMinMaxLoc(salida,&minval,&maxval,&Minpos, &Maxpos);
		cvCircle(frame,cvPoint(Maxpos.x+G_Template->width/2,
					Maxpos.y+G_Template->height/2),20,CV_RGB(200,0,0),1,CV_AA);

	cvShowImage("Frame",frame);
	cvShowImage("salida",salida);
	
	char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

	cvReleaseImage(&salida);
	cvReleaseImage(&GRIS);
cvReleaseCapture( &capture );
cvDestroyWindow( "salida" );
}