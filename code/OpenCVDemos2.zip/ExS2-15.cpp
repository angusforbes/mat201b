#include "highgui.h"
#include "cv.h"



int main( int argc, char** argv ) {
	
	IplImage * BINARY;
	int controlPos=128;

    CvMemStorage* storage = cvCreateMemStorage(0);
    CvSeq* contour = 0;


	cvNamedWindow( "ExS2-15", CV_WINDOW_AUTOSIZE );
	cvNamedWindow( "Binary", CV_WINDOW_AUTOSIZE );

	cvCreateTrackbar("ThresholdLow","ExS2-15",&controlPos,255,NULL);
	cvSetTrackbarPos("ThresholdLow","ExS2-15",128);


	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	BINARY = cvCreateImage(cvGetSize(frame),IPL_DEPTH_8U,1);

	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		}
		cvCvtColor(frame,BINARY,CV_BGR2GRAY);
		cvThreshold(BINARY,BINARY,controlPos,255,CV_THRESH_BINARY_INV);
		cvShowImage("Binary",BINARY);
		cvFindContours(BINARY,storage,&contour,sizeof(CvContour),
						CV_RETR_EXTERNAL,CV_CHAIN_APPROX_NONE );
		for( ; contour != 0; contour = contour->h_next )
		{
			    cvDrawContours( frame, contour, CV_RGB(200,0,0),
						CV_RGB(0,0,200), 2, 3, 8 );
		 }

			cvShowImage("ExS2-15",frame);

		
		char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

	cvReleaseImage(&BINARY);
cvReleaseCapture( &capture );
cvDestroyWindow( "Binary" );
cvDestroyWindow( "ExS2-15" );
}