#include "highgui.h"
#include "cv.h"
#include <stdio.h>


int main( int argc, char** argv ) {
	int controlPos=128;

	IplImage * BINARY;
	IplImage * letreros;
	CvFont  fuente;
    CvMemStorage* storage = cvCreateMemStorage(0);
    CvSeq* contour = 0;
	CvMoments* moments;
	double n20,n11,n02;
	char buffer [50];
	cvInitFont(&fuente,CV_FONT_HERSHEY_SIMPLEX,1.0,
		1.0,0.0);
	moments = (CvMoments *)cvAlloc(sizeof(CvMoments));

	cvNamedWindow( "ExS2-18", CV_WINDOW_AUTOSIZE );
	cvNamedWindow( "salida", CV_WINDOW_AUTOSIZE );

	cvCreateTrackbar("ThresholdLow","ExS2-18",&controlPos,255,NULL);
	cvSetTrackbarPos("ThresholdLow","ExS2-18",128);

	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	BINARY = cvCreateImage(cvGetSize(frame),IPL_DEPTH_8U,1);
	letreros = cvCreateImage(cvSize(400,400),IPL_DEPTH_8U,1);


	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

		cvSet(letreros,cvScalarAll(255));
		cvCvtColor(frame,BINARY,CV_BGR2GRAY);
		cvThreshold(BINARY,BINARY,controlPos,255,CV_THRESH_BINARY_INV);
		cvCvtColor(BINARY,frame,CV_GRAY2BGR);
		cvFindContours(BINARY,storage,&contour,sizeof(CvContour),
			CV_RETR_EXTERNAL,CV_CHAIN_APPROX_NONE );
		for( ; contour != 0; contour = contour->h_next )
			{
			if (contour->total>200){
					cvDrawContours( frame, contour, CV_RGB(200,0,0),
					CV_RGB(0,0,200), 0, 3, 8 );
					break;
				}
		}
		if (contour != 0){
			cvMoments(contour,moments);
			n20 = cvGetNormalizedCentralMoment(moments,2,0);
			n11 = cvGetNormalizedCentralMoment(moments,1,1);
			n02 = cvGetNormalizedCentralMoment(moments,0,2);
			cvRectangle(letreros,cvPoint(240,50),
				cvPoint(240+(n20*100),20),CV_RGB(0,0,0),-1);
			cvRectangle(letreros,cvPoint(240,150),
				cvPoint(240+(n11*100),120),CV_RGB(0,0,0),-1);
			cvRectangle(letreros,cvPoint(240,250),
				cvPoint(240+(n02*100),220),CV_RGB(0,0,0),-1);
			cvPutText(letreros,"n20",cvPoint(5,50),
				&fuente,CV_RGB(0,0,0));
			cvPutText(letreros,"n11",cvPoint(5,150),
				&fuente,CV_RGB(0,0,0));
			cvPutText(letreros,"n02",cvPoint(5,250),
				&fuente,CV_RGB(0,0,0));
		}
	
		cvShowImage("salida",letreros);
		cvShowImage("ExS2-18",frame);


		char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}
	cvReleaseImage(&BINARY);
	cvReleaseImage(&letreros);
	cvReleaseMemStorage(&storage);
cvReleaseCapture( &capture );
cvDestroyWindow( "SimpIP" );
}