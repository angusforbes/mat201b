#include "highgui.h"
#include "cv.h"



int main( int argc, char** argv ) {
	
		CvBox2D Ellipdesc;

	IplImage * BINARY;
	int controlPos=128/10.0;
	IplImage * TARGET;

	CvMemStorage* storage;
	storage = cvCreateMemStorage(0);
	CvSeq* contarget;
	contarget = 0;

	TARGET=cvLoadImage("murci.png",CV_LOAD_IMAGE_GRAYSCALE);
	cvNot(TARGET,TARGET);
	cvFindContours(TARGET,storage,&contarget,sizeof(CvContour),
			 CV_RETR_EXTERNAL,CV_CHAIN_APPROX_NONE );


	CvMemStorage* storage2;
	CvSeq* contodos;

	storage2 = cvCreateMemStorage(0);
	contodos = 0;


	cvNamedWindow( "ExS2-19", CV_WINDOW_AUTOSIZE );

	cvCreateTrackbar("ThresholdLow","ExS2-19",&controlPos,255,NULL);
	cvSetTrackbarPos("ThresholdLow","ExS2-19",100);


	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	BINARY = cvCreateImage(cvGetSize(frame),IPL_DEPTH_8U,1);

	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		}
		cvCvtColor(frame,BINARY,CV_BGR2GRAY);
		cvThreshold(BINARY,BINARY,100,255,CV_THRESH_BINARY_INV);
	   cvCvtColor(BINARY,frame,CV_GRAY2BGR);

	cvFindContours(BINARY,storage2,&contodos,sizeof(CvContour),
			CV_RETR_EXTERNAL,CV_CHAIN_APPROX_NONE );
	for( ; contodos != 0; contodos = contodos->h_next )
		{
			double cuanto=cvMatchShapes(contarget,contodos,CV_CONTOURS_MATCH_I1,0);
			if ((cuanto <controlPos/10.0)&(contodos->total>10)){
				Ellipdesc=cvFitEllipse2(contodos);
				Ellipdesc.angle=-Ellipdesc.angle;
				cvEllipseBox(frame,Ellipdesc,CV_RGB(200,0,0),2,8);
		     }


		 }

			cvShowImage("ExS2-19",frame);

		
		char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

	cvReleaseImage(&BINARY);
	cvReleaseMemStorage(&storage2);
	cvReleaseMemStorage(&storage);

	cvReleaseCapture( &capture );
cvDestroyWindow( "ExS2-19" );
}