#include "highgui.h"
#include "cv.h"


int main( int argc, char** argv ) {
	
	IplImage * Temp1;
	IplImage * Temp2;

	cvNamedWindow( "SimpIP", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );
	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp2=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);



	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
		cvCvtColor(frame,Temp1,CV_BGR2GRAY);
		cvErode(Temp1,Temp2,NULL,3);

		cvCvtColor(Temp2,frame,CV_GRAY2BGR);



		 cvShowImage( "SimpIP", frame );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

cvReleaseImage(&Temp1);
cvReleaseImage(&Temp2);
cvReleaseCapture( &capture );
cvDestroyWindow( "SimpIP" );
}