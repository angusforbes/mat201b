#include "highgui.h"
#include "cv.h"

int main( int argc, char** argv ) {
	
		IplImage * Temp1;
	CvPoint2D32f srcQua[4], dstQua[4];
	CvMat *T;
	T = cvCreateMat(3,3,CV_32FC1);

	cvNamedWindow( "Exs2-6", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 3);

	srcQua[0].x = 0; 
	srcQua[0].y = 0;
	srcQua[1].x = 0; 
	srcQua[1].y = frame->height - 1;	
	srcQua[2].x = frame->width - 1;  
	srcQua[2].y = frame->height - 1;
	srcQua[3].x = frame->width - 1;  
	srcQua[3].y = 0;


	dstQua[0].x = 0; 
	dstQua[0].y = 0;
	dstQua[1].x = frame->width*.4; 
	dstQua[1].y = frame->height - 1;
	dstQua[2].x = frame->width*.6; 
	dstQua[2].y = frame->height -1;
	dstQua[3].x = frame->width -1; 
	dstQua[3].y = 0;

	cvGetPerspectiveTransform( srcQua, dstQua, T );

	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

		cvWarpPerspective(frame,Temp1,T,CV_INTER_LINEAR | CV_WARP_FILL_OUTLIERS,CV_RGB(130,20,15));



		 cvShowImage( "Exs2-6", Temp1 );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "Exs2-6" );
}