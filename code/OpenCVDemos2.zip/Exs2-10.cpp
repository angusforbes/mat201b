#include "highgui.h"
#include "cv.h"

int G_Radio =1;

void onCambio(int pos){
	G_Radio=pos;
}

void fftShift2D(IplImage* entrada){
	IplImage * Temp1;
	Temp1=cvCreateImage( cvGetSize(entrada),IPL_DEPTH_32F, 1);
	
	cvSetImageROI(entrada, cvRect(0,0,entrada->width/2,entrada->height/2));
	cvSetImageROI(Temp1, cvRect(entrada->width/2,entrada->height/2,
									entrada->width/2,entrada->height/2));
	cvCopy(entrada,Temp1);

	cvSetImageROI(Temp1, cvRect(0,0,entrada->width/2,entrada->height/2));
	cvSetImageROI(entrada, cvRect(entrada->width/2,entrada->height/2,
									entrada->width/2,entrada->height/2));
	cvCopy(entrada,Temp1);

	cvSetImageROI(entrada, cvRect(0,entrada->height/2,
		                  entrada->width/2,entrada->height/2));
	cvSetImageROI(Temp1, cvRect(entrada->width/2,0,
									entrada->width/2,entrada->height/2));
	cvCopy(entrada,Temp1);

	cvSetImageROI(Temp1, cvRect(0,entrada->height/2,
		                  entrada->width/2,entrada->height/2));
	cvSetImageROI(entrada, cvRect(entrada->width/2,0,
									entrada->width/2,entrada->height/2));
	cvCopy(entrada,Temp1);

	cvResetImageROI(entrada);
	cvResetImageROI(Temp1);
	cvCopy(Temp1,entrada);
	cvReleaseImage(&Temp1);
}




int main( int argc, char** argv ) {
	
	IplImage * Temp1;
	IplImage * Temp1float;
	IplImage * Temp2;
	IplImage * Temp3;

	IplImage * Espectro;
	IplImage * EspecFilt;
	IplImage * Magni;
	IplImage * Phase;
	IplImage * masca;

	int controlPos;

	cvNamedWindow( "Spectrum", CV_WINDOW_AUTOSIZE );
	cvNamedWindow( "Output", CV_WINDOW_AUTOSIZE );
	cvCreateTrackbar("radio","Spectrum",&controlPos,80,onCambio);
	cvSetTrackbarPos("radio","Spectrum",1);


	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp3=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	masca=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp1float=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);
	Magni=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);
	Phase=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);
	Temp2=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);
	Espectro=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 2);
	EspecFilt=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 2);




	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

		cvZero(Temp2);

		cvCvtColor(frame,Temp1,CV_BGR2GRAY);
		cvConvertScale(Temp1,Temp1float);

		cvMerge(Temp1float,Temp2,NULL,NULL,Espectro);
		cvDFT(Espectro,Espectro,CV_DXT_FORWARD);

		cvSet(masca,cvScalarAll(0));
		cvCircle(masca,cvPoint(frame->width/2,frame->height/2),G_Radio,cvScalarAll(255),-1,8);


		cvSplit(Espectro,Temp1float,Temp2,NULL,NULL);
		cvCartToPolar(Temp1float,Temp2,Magni,Phase);
		cvLog(Magni,Magni);
		fftShift2D(Magni);
		cvConvertScale(Magni,Temp1,20);
		cvNot(Temp1,Temp3);
		cvCopy(Temp3,Temp1,masca);

		 cvShowImage( "Spectrum", Temp1 );
		cvCopy(masca,Temp1);

		cvConvertScale(Temp1,Temp1float,1/255.0);
		fftShift2D(Temp1float);

		cvZero(Temp2);
		cvMerge(Temp1float,Temp2,NULL,NULL,EspecFilt);
		cvMulSpectrums(Espectro,EspecFilt,Espectro,1);
		cvDFT(Espectro,Espectro,CV_DXT_INV_SCALE);
		cvSplit(Espectro,Temp1float,Temp2,NULL,NULL);
		cvConvertScale(Temp1float,Temp1);
		cvShowImage("Output",Temp1);

	 char c = cvWaitKey(60);
	 if( (c & 255) == 27 ) break;
}

	cvReleaseImage(&Temp1);
	cvReleaseImage(&Temp1float);
	cvReleaseImage(&Temp3);

	cvReleaseImage(&Temp2);
	cvReleaseImage(&Espectro);
	cvReleaseImage(&EspecFilt);
	cvReleaseImage(&Magni);
	cvReleaseImage(&Phase);
	cvReleaseImage(&masca);
cvReleaseCapture( &capture );
cvDestroyWindow( "Exs2-10" );
}