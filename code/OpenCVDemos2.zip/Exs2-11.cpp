#include "highgui.h"

#include "cv.h"

int G_Radio =1;

void onCambio(int pos){
	G_Radio=pos;
}

int main( int argc, char** argv ) {
	
			IplImage * Temp1;
	IplImage * Temp1float;
	IplImage * Temp3;
	IplImage * masca;
	IplImage * Temp2float;
	int controlPos;

	cvNamedWindow( "DCT", CV_WINDOW_AUTOSIZE );
	cvNamedWindow( "Output", CV_WINDOW_AUTOSIZE );
	cvCreateTrackbar("Coef","DCT",&controlPos,150,onCambio);
	cvSetTrackbarPos("Coef","DCT",0);


	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp3=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	masca=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp1float=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);
	Temp2float=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);


	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }

		cvCvtColor(frame,Temp1,CV_BGR2GRAY);
		cvConvertScale(Temp1,Temp1float);

		cvDCT(Temp1float,Temp1float,CV_DXT_FORWARD);

		cvSet(masca,cvScalarAll(0));
		cvRectangle(masca,cvPoint(0,0),cvPoint(G_Radio,G_Radio),cvScalarAll(255),-1);

		cvConvertScale(Temp1float,Temp1);
		cvNot(Temp1,Temp3);
		cvCopy(Temp3,Temp1,masca);
		cvShowImage("DCT",Temp1);
	
		cvCopy(masca,Temp1);
		cvConvertScale(masca,Temp2float,1/255.0);
		cvMul(Temp1float,Temp2float,Temp1float);
		cvDCT(Temp1float,Temp1float,CV_DXT_INVERSE);

		cvConvertScale(Temp1float,Temp1);
		cvShowImage("Output",Temp1);
	
		char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

	cvReleaseImage(&Temp1);
	cvReleaseImage(&Temp1float);
	cvReleaseImage(&Temp2float);
	cvReleaseImage(&Temp3);

	cvReleaseImage(&masca);

cvReleaseCapture( &capture );
cvDestroyWindow( "Output" );
cvDestroyWindow( "DCT" );

}