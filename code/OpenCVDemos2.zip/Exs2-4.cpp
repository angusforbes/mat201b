#include "highgui.h"
#include "cv.h"

int main( int argc, char** argv ) {
	
		IplImage * Temp1;
		CvMat T;
		double Tmat[]={.2165 , -.125 ,50, .125, .2165, 50};

	cvNamedWindow( "SimpIP", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 3);


	cvInitMatHeader(&T, 2,3, CV_64FC1, Tmat);


	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
	cvWarpAffine(frame,Temp1,&T,CV_INTER_LINEAR | CV_WARP_FILL_OUTLIERS,CV_RGB(130,20,15));


		 cvShowImage( "SimpIP", Temp1 );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

cvReleaseImage(&Temp1);
cvReleaseCapture( &capture );
cvDestroyWindow( "SimpIP" );
}