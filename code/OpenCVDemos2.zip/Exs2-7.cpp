#include "highgui.h"

int G_Radio;
#define Nx 320
#define Ny 240


void onCambio(int pos){
	G_Radio=pos;
}

void preproc(IplImage* entrada){
	
	CvScalar s;
		for (int k=0;k<Nx;k++){
			for (int q=0;q<Ny;q++){
			s=cvGet2D(entrada,q,k); 
			s.val[0]=s.val[0]*(int)pow((-1.0),k+q);
			cvSet2D(entrada,q,k,s);
			}
		}
}

int main( int argc, char** argv ) {
	IplImage * Temp1;
	IplImage * Temp1float;
	IplImage * Temp2;
	IplImage * Espectro;
	IplImage * Magni;
	IplImage * Phase;

	int controlPos;

	cvNamedWindow( "Exs2-7", CV_WINDOW_AUTOSIZE );
	cvNamedWindow( "Espectro", CV_WINDOW_AUTOSIZE );

	cvCreateTrackbar("radio","Exs2-7",&controlPos,80,onCambio);
	cvSetTrackbarPos("radio","Exs2-7",1);

	Temp1 = cvCreateImage( cvSize(Nx,Ny),IPL_DEPTH_8U, 1 );
	Espectro=cvCreateImage( cvSize(Nx,Ny),IPL_DEPTH_32F, 2);
	Magni=cvCreateImage( cvSize(Nx,Ny),IPL_DEPTH_32F, 1);
	Phase=cvCreateImage( cvSize(Nx,Ny),IPL_DEPTH_32F, 1);
	Temp1float=cvCreateImage( cvSize(Nx,Ny),IPL_DEPTH_32F, 1);
	Temp2=cvCreateImage( cvSize(Nx,Ny),IPL_DEPTH_32F, 1);



	for (;;)
	{
		char c = cvWaitKey(100);
		if( c == 27 ) break;
		cvSet(Temp1,cvScalarAll(0));
		cvCircle(Temp1,cvPoint(Nx/2,Ny/2),G_Radio,cvScalarAll(255),-1,8);
		cvShowImage("Exs2-7",Temp1);
		cvZero(Temp2);
		cvConvertScale(Temp1,Temp1float);
		preproc(Temp1float);
		cvMerge(Temp1float,Temp2,NULL,NULL,Espectro);
		cvDFT(Espectro,Espectro,CV_DXT_FORWARD);
		cvSplit(Espectro,Temp1float,Temp2,NULL,NULL);
    	cvCartToPolar(Temp1float,Temp2,Magni,Phase);
	    cvLog(Magni,Magni);
		cvConvertScale(Magni,Temp1,20);
		cvShowImage("Espectro",Temp1);

	}
	cvReleaseImage(&Temp1);
	cvReleaseImage(&Temp1float);
	cvReleaseImage(&Magni);
	cvReleaseImage(&Phase);

	cvReleaseImage(&Temp2);
	cvReleaseImage(&Espectro);

}