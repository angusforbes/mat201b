#include "highgui.h"
#include "cv.h"


void fftShift2D(IplImage* entrada){
	IplImage * Temp1;
	Temp1=cvCreateImage( cvGetSize(entrada),IPL_DEPTH_32F, 1);
	
	cvSetImageROI(entrada, cvRect(0,0,entrada->width/2,entrada->height/2));
	cvSetImageROI(Temp1, cvRect(entrada->width/2,entrada->height/2,
									entrada->width/2,entrada->height/2));
	cvCopy(entrada,Temp1);

	cvSetImageROI(Temp1, cvRect(0,0,entrada->width/2,entrada->height/2));
	cvSetImageROI(entrada, cvRect(entrada->width/2,entrada->height/2,
									entrada->width/2,entrada->height/2));
	cvCopy(entrada,Temp1);

	cvSetImageROI(entrada, cvRect(0,entrada->height/2,
		                  entrada->width/2,entrada->height/2));
	cvSetImageROI(Temp1, cvRect(entrada->width/2,0,
									entrada->width/2,entrada->height/2));
	cvCopy(entrada,Temp1);

	cvSetImageROI(Temp1, cvRect(0,entrada->height/2,
		                  entrada->width/2,entrada->height/2));
	cvSetImageROI(entrada, cvRect(entrada->width/2,0,
									entrada->width/2,entrada->height/2));
	cvCopy(entrada,Temp1);

	cvResetImageROI(entrada);
	cvResetImageROI(Temp1);
	cvCopy(Temp1,entrada);
	cvReleaseImage(&Temp1);
}




int main( int argc, char** argv ) {
	
	IplImage * Temp1;
	IplImage * Temp1float;
	IplImage * Temp2;
	IplImage * Espectro;
	IplImage * Magni;
	IplImage * Phase;


	cvNamedWindow( "Exs2-9", CV_WINDOW_AUTOSIZE );
	CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
		if( !capture ) {
			fprintf( stderr, "ERROR: capture is NULL \n" );
			getchar();     return -1;  
		}
	
	IplImage* frame;

	frame = cvQueryFrame( capture );

	
	Temp1=cvCreateImage( cvGetSize(frame),IPL_DEPTH_8U, 1);
	Temp1float=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);

	Magni=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);
	Phase=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);

	Temp2=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 1);

	Espectro=cvCreateImage( cvGetSize(frame),IPL_DEPTH_32F, 2);


	while(1) {
		frame = cvQueryFrame( capture );
		if( !frame ){

			cvSetCaptureProperty(capture,
			CV_CAP_PROP_POS_FRAMES,0);
			frame = cvQueryFrame( capture );
		 }
	cvZero(Temp2);
	cvCvtColor(frame,Temp1,CV_BGR2GRAY);
	cvConvertScale(Temp1,Temp1float);
	cvMerge(Temp1float,Temp2,NULL,NULL,Espectro);
	cvDFT(Espectro,Espectro,CV_DXT_FORWARD);
	cvCvtColor(Temp1,frame,CV_GRAY2BGR);
	cvSplit(Espectro,Temp1float,Temp2,NULL,NULL);
	cvCartToPolar(Temp1float,Temp2,Magni,Phase);
	cvLog(Magni,Magni);
	fftShift2D(Magni);
	cvConvertScale(Magni,Temp1,20);


		 cvShowImage( "Exs2-9", Temp1 );
	 char c = cvWaitKey(10);
	 if( (c & 255) == 27 ) break;
}

	cvReleaseImage(&Temp1);
	cvReleaseImage(&Temp1float);
	cvReleaseImage(&Magni);
	cvReleaseImage(&Phase);

	cvReleaseImage(&Temp2);
	cvReleaseImage(&Espectro);

cvReleaseCapture( &capture );
cvDestroyWindow( "Exs2-9" );
}