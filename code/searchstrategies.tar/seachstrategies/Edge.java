package seachstrategies;

public class Edge {
  double cost;
  Vertex from;
  Vertex dest;

  public Edge(Vertex from, Vertex dest, double cost) {
    this.cost = cost;
    this.from = from;
    this.dest = dest;
  }

  public String toString() {
    return "[" + from + "] --(" + cost + ")--> [" + dest + "]";
  }
}
