package seachstrategies;

public class Main {

    public static void main(String[] args) {
      new Main();
    }

    public Main() {
      SearchTree tree = SearchTree.initializeTree();
      //tree.dfs(tree.start);
      tree.bfs(tree.start);

      System.out.println("best route = " + tree.bestRoute);
    }
}
