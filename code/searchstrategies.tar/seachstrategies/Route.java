package seachstrategies;

import java.util.List;

public class Route {
  double total;
  List<Edge> path;

  public Route(double total, List<Edge> path) {
    this.total = total;
    this.path = path;
  }

  public Edge getLast() {
    if (path.size() > 0)
    {
      return path.get(path.size() - 1);
    }  else {
      return null;
    }
  }
  public String toString() {
    String s = "";

    for (int i = 0; i < path.size(); i++) {
      Edge e = path.get(i);
      if (i == 0) {
	s+= "[" + e.from + "] --(" + e.cost + ")--> [" + e.dest + "]";
      } else {
	s+= " --(" + e.cost + ")--> [" + e.dest + "]";
      }
    }

    s += " : " + total + " miles.";

    return s;
  }
}
