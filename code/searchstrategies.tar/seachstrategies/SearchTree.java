package seachstrategies;

import java.util.ArrayList;
import java.util.List;

public class SearchTree {

  Vertex start;
  Vertex end;

  public SearchTree(Vertex start, Vertex end) {
    this.start = start;
    this.end = end;
  }

  public static SearchTree initializeTree() {
    Vertex A = new Vertex("Oakland");
    Vertex B = new Vertex("Bakersfield");
    Vertex C = new Vertex("San Francisco");
    Vertex D = new Vertex("Goleta");
    Vertex E = new Vertex("Santa Barbara");
    Vertex F = new Vertex("San Luis Obispo");
    Vertex Z = new Vertex("Los Angeles");

    //A.edges.add(new Edge(A, Z, 5));
    A.edges.add(new Edge(A, B, 12));
    B.edges.add(new Edge(B, Z, 340));
    B.edges.add(new Edge(B, C, 1));
    B.edges.add(new Edge(B, D, 1001));
    //B.edges.add(new Edge(C, B, 101));
    B.edges.add(new Edge(B, E, 1501));
    C.edges.add(new Edge(C, D, 11));
    D.edges.add(new Edge(D, E, 140));
    D.edges.add(new Edge(D, F, 7));
    F.edges.add(new Edge(F, Z, 3));
    E.edges.add(new Edge(E, Z, 1330));

    return new SearchTree(A, Z);
  }

  public String tabs(int level) {

    String s = "";
    for (int i = 0; i < level; i++) {
      s += "\t";
    }
    return s;
  }
  double best = 1000;
  Route bestRoute;

  public void checkIfBestRoute(Route route, int level) {
    if (route.total < best) {
      System.out.println(tabs(level) + "\t... best current route = " + route.total);
      best = route.total;
      bestRoute = route;
    }
  }

  public void dfs(Vertex root) {
    for (Edge e : root.edges) {
      System.out.println(tabs(0) + e);
      Route r = new Route(0, new ArrayList<Edge>());
      if (dfs(e, r, 1)) {
	checkIfBestRoute(r, 0);
      }
    }
  }

  public boolean dfs(Edge e, Route route, int level) {

    route.path.add(e);
    route.total += e.cost;

    if (e.dest == end) {
      return true;
    }

    for (Edge ne : e.dest.edges) {
      System.out.println(tabs(level) + ne);

      if (route.total + ne.cost > best) {
	System.out.println(tabs(level) + "\t +" + ne.cost + "? ... not going this way!");
	continue;
      }
      List<Edge> path = new ArrayList<Edge>(route.path);
      Route r2 = new Route(route.total, path);

      if (dfs(ne, r2, level + 1)) {
	checkIfBestRoute(r2, level);
      }
    }

    return false;
  }

  public void bfs(Vertex root) {

    List<Route> rs = new ArrayList<Route>();

    for (Edge e : root.edges) {
      Route r = new Route(0, new ArrayList<Edge>());
      r.path.add(e);
      r.total += e.cost;
      rs.add(r);
    }

    for (Route nr : rs) {
      System.out.println(tabs(0) + nr);
      if (nr.path.get(nr.path.size() - 1).dest == end) {
	checkIfBestRoute(nr, 0);
      }
    }

    bfs(rs, 1);

  }

  public boolean bfs(List<Route> routes, int level) {

    List<Route> rs = new ArrayList<Route>();

    for (Route r : routes) {
      Edge e = r.path.get(r.path.size() - 1);

      for (Edge ee : e.dest.edges) {
	if (r.total + ee.cost > best) {
	  continue;
	}

	List<Edge> path = new ArrayList<Edge>(r.path);
	path.add(ee);

	Route r2 = new Route(r.total + ee.cost, path);
	rs.add(r2);
      }
    }


    for (Route nr : rs) {
      System.out.println(tabs(level) + nr.getLast());
      if (nr.path.get(nr.path.size() - 1).dest == end) {
	checkIfBestRoute(nr, level);
      }
    }

    if (rs.size() > 0) {
      bfs(rs, level + 1);
    }

    return false;
  }
}
