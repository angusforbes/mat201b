package seachstrategies;

import java.util.ArrayList;
import java.util.List;

public class Vertex {
  String name;
  List<Edge> edges = new ArrayList<Edge>();

  public Vertex(String name) {
    this.name = name;
  }

  public String toString() {
    return this.name;
  }
}
