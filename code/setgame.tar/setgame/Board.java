/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package setgame;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author angus
 */
public class Board {

  List<Card> cards = new ArrayList<Card>();

  public Board(List<Card> cards) {
    this.cards = cards;
  }

  public List<CardSet> bruteForce() {

    List<CardSet> legalSets = new ArrayList<CardSet>();
    
    for (int a = 0; a < cards.size() - 2; a++) {
      for (int b = a + 1; b < cards.size() - 1; b++) {
	for (int c = b + 1; c < cards.size(); c++) {

	  if (Card.checkTripletForPair(cards.get(a), cards.get(b), cards.get(c))) {
	    legalSets.add(new CardSet(cards.get(a), cards.get(b), cards.get(c)));
	  }

	}
      }
    }

    return legalSets;
  }

  public String toString() {
    String s = "";

    for (int y = 0; y < 3; y++) {
      for (int x = 0; x < 4; x++) {
	Card c = cards.get(x * 3 + y);
	s += (c + "\t");
      }
      s += "\n";
    }

    return s;
  }
}
