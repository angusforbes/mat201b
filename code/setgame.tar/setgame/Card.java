package setgame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Card {

  String color;
  String number;
  String shape;
  String fill;

  public Card(String color, String number, String shape, String fill) {
    this.color = color;
    this.number = number;
    this.shape = shape;
    this.fill = fill;
  }

  public String toString() {
    return color + ":" + number + ":" + shape + ":" + fill;
  }

  public static boolean checkEquals(String a, String b) {
   Main.numChecks++;
   return (a.equals(b)) ? true : false;
  }
  
  public static boolean allSame(String a, String b, String c) {
    boolean c1 = checkEquals(a, b);
    boolean c2 = checkEquals(a, c);

    return (c1 && c2) ? true : false;
    //return (checkEquals(a, b) && checkEquals(a, c)) ? true : false;
  }

  public static boolean allDifferent(String a, String b, String c) {
    boolean c1 = checkEquals(a, b);
    boolean c2 = checkEquals(a, c);
    boolean c3 = checkEquals(b, c);
    return (!c1 && !c2 && !c3) ? true : false;
    //return (!checkEquals(a, b) && !checkEquals(a, c) && !checkEquals(b, c)) ? true : false;
  }

  public static boolean checkMatch(String a, String b, String c) {
    boolean c1 = allSame(a,b,c);
    boolean c2 = allDifferent(a,b,c);
    return (c1 || c2) ? true : false;
    //return (allSame(a,b,c) || allDifferent(a,b,c)) ? true : false;
  }

  public static boolean checkTripletForPair(Card a, Card b, Card c) {
   boolean c1 = checkMatch(a.color, b.color, c.color);
   boolean c2 = checkMatch(a.number, b.number, c.number);
   boolean c3 = checkMatch(a.shape, b.shape, c.shape);
   boolean c4 = checkMatch(a.fill, b.fill, c.fill);

   return (c1 && c2 && c3 && c4)? true : false;
 
//  return (checkMatch(a.color, b.color, c.color) &&
//	    checkMatch(a.number, b.number, c.number) &&
//	    checkMatch(a.shape, b.shape, c.shape) &&
//	    checkMatch(a.fill, b.fill, c.fill)) ? true : false;
  }

  public static List<Card> makeDeck() {
    List<Card> deck = new ArrayList<Card>();
    for (int a = 0; a < 3; a++) {
      for (int b = 0; b < 3; b++) {
	for (int c = 0; c < 3; c++) {
	  for (int d = 0; d < 3; d++) {
	    deck.add(makeCard(a, b, c, d));
	  }
	}
      }
    }

    System.out.println("deck size = " + deck.size());
    Collections.shuffle(deck);
    return deck;
  }

  public static Card makeCard(int a, int b, int c, int d) {
    String color = "";
    switch (a) {
      case 0:
	color = "R";
	break;
      case 1:
	color = "G";
	break;
      case 2:
	color = "B";
	break;
    }

    String number = "";
    switch (b) {
      case 0:
	number = "1";
	break;
      case 1:
	number = "2";
	break;
      case 2:
	number = "3";
	break;
    }

    String shape = "";
    switch (c) {
      case 0:
	shape = "D";
	break;
      case 1:
	shape = "S";
	break;
      case 2:
	shape = "P";
	break;
    }

    String fill = "";
    switch (d) {
      case 0:
	fill = "E";
	break;
      case 1:
	fill = "H";
	break;
      case 2:
	fill = "F";
	break;
    }

    return new Card(color, number, shape, fill);
  }
}
