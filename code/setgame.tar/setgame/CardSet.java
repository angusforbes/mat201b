package setgame;

import java.util.List;

public class CardSet {
  Card a;
  Card b;
  Card c;

  public CardSet(Card a, Card b, Card c) {
    this.a = a;
    this.b = b;
    this.c = c;
  }

  public String toString() {
    return a + " | " + b + " | " + c;
  }

  public static void printSets(List<CardSet> sets) {
    for (CardSet set : sets)
	System.out.println("Set : " + set);
  }
}
