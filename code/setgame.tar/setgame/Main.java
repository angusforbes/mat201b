package setgame;

import java.util.ArrayList;
import java.util.List;

public class Main {

  static int numChecks = 0;
  Board board;
  List<Card> deck = new ArrayList<Card>();
  List<CardSet> sets = new ArrayList<CardSet>();
  int boardNumber = 1;
  int deckPos = 0;

  public static void main(String[] args) {
    Main game = new Main();
    game.test();
  }

  public void test() {

    for (int i = 0; i < 1; i++) {
      numChecks = 0;

      System.out.println("\nGame #" + i + "\n");
      initializeDeck();
      makeFirstBoard();

      System.out.println(board);
      
      sets = board.bruteForce();

      CardSet.printSets(sets);

      System.out.println("\nfound " + sets.size() + " sets in " + numChecks + " steps.");

      //if (sets.size() == 6) {System.exit(0);}
    }
  }

  public void makeFirstBoard() {
    board = new Board(deck.subList(0,12));
  }

  public void initializeDeck() {
    sets.clear();
    deck.clear();
    deck = Card.makeDeck();
  }

  
}
